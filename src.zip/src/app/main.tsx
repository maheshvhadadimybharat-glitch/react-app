// src/main.tsx
import React from "react";
import ReactDOM from "react-dom/client";
import AppProvider from "./providers/AppProvider";
import AppRouter from "./router/AppRouter";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <AppProvider>
    <AppRouter />
  </AppProvider>
);