// src/app/router/AppRouter.tsx
import { BrowserRouter, Route, Routes } from "react-router-dom";
import DashboardPage from "../../pages/dashboard/DashboardPage";
import LoginPage from "../../pages/auth/LoginPage";

const AppRouter = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<DashboardPage/>}/>
      <Route path="/login" element={<LoginPage/>}/>
    </Routes>
  </BrowserRouter>
);

export default AppRouter;