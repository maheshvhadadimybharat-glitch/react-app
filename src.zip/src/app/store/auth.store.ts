// src/app/store/auth.store.ts

import { create } from "zustand";

type AuthState = {
  user: any;
  setUser: (user: any) => void;
};

export const userAuthStore = create<AuthState>((set) => ({
  user: null,
  setUser: (user) => set({ user }),
}))