import { useUsers } from "../../features/user/hooks/useUsers";

const DashboardPage = () => {
  const { data, isLoading } = useUsers();

  if (isLoading) return <p>Loading...</p>;

  return(
    <div>
      {data?.map((user: any) => (
        <p key={user.id}> {user.name} </p>
      ))}
    </div>
  )
}

export default DashboardPage;