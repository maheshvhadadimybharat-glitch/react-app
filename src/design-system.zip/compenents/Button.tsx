import React from "react";
import type { Theme } from "../design-system/theme";
import { theme } from "../design-system/theme";
import { resolveToken } from "../design-system/utils";

type ButtonVariant =
  keyof typeof theme.components.button.variants;

interface ButtonProps {
  label: string;
  variant?: ButtonVariant;
  onClick?: () => void;
  type?: "button" | "submit" | "reset";
  disabled?: boolean;
}

const Button = ({
  label,
  variant = "primary",
  onClick,
  type = "button",
  disabled = false,
}: ButtonProps) => {
  
  const componentConfig = theme.components?.button;

const baseStyles = componentConfig?.base || {};
const variantStyles =
  componentConfig?.variants?.[variant] || {};

 const getStyles = (): React.CSSProperties => {
  const combinedStyles = {
    ...baseStyles,
    ...variantStyles,
  };

  const styleMap: Record<string, string> = {
    background: "backgroundColor",
  };



  const resolvedStyles = Object.entries(combinedStyles).reduce(
    (acc, [key, value]) => {
      
      const cssKey = key === "background" ? "backgroundColor" : key;

      acc[cssKey as any] = resolveToken(String(value), theme);
      return acc;
    },
    {} as React.CSSProperties
  );

    //console.log("Resolved Styles:", resolvedStyles);

    //console.log(resolveToken("{color.primary.500}", theme));

    console.log({
      variantStyles,
      resolved: resolvedStyles,
    });

  return {
    padding:
      resolveToken("{spacing.sm}", theme) +
      " " +
      resolveToken("{spacing.md}", theme),
    borderRadius: resolveToken("{radius.md}", theme),
    fontWeight: 600,
    border: "none",
    cursor: disabled ? "not-allowed" : "pointer",
    margin: "5px",
    opacity: disabled ? 0.6 : 1,

    ...resolvedStyles, // 🔥 KEEP THIS LAST
  };
};;

  return (
    <button
      style={getStyles()}
      onClick={onClick}
      type={type}
      disabled={disabled}
    >
      {label}
    </button>
  );
};

export default Button;